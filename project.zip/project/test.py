class A:
    pass

animal = A()

print(type(animal).__name__)